package cs3500.music.controller;

/**
 * Created by ErinZhang on 3/31/16.
 */
public interface IController {

}
